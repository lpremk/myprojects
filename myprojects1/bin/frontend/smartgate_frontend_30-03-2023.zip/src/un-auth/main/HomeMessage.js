export default function HomeMessage(){
    return(<>
        <p>Home Message</p>
    </>)
}