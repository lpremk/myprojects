export default function Search() {
    return(
    <div>
        <div className="container d-flex justify-content-center">
            <div className='patient-acknowledgement'>
                <h5 className="text-center">This is search component</h5>
                
            </div>
        </div>
    </div>
    )
}
