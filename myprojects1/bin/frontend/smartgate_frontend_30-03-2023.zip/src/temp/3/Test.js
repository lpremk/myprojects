import ParentComponent from "./ParentComponent";

export default function Test(){
    return (<>
           <h3>Parent to Child Component (test2)</h3><br/>
           <ParentComponent/>
    </>)
}